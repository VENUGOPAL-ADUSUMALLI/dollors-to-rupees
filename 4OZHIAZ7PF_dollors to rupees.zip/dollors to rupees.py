a=float(input())
print(a*83.24)